<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IRISH DEER </title>
    <?php include("includes/css.php")?>
  </head>
  <body class="nav-md">
    <div class="container body">
    <div class="position-absolute mt-3 ml-5"><h4 class="pl-5"><b>Dashboard</b></h4></div>
      <div class="main_container">
          
        <?php include("includes/side_nav.php")?>

          <!-- page content -->
          <div class="right_col" role="main">
            <!-- top box -->
            <section class="top_box">
            <div class="row">
              <div class="col-lg-2 col-6">
                <!-- small box -->
                <div class="small-box">
                  <div class="inner">
                    <h5>Lifetime Sales</h5>
                     <p>Rs.45,233.00</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-bag"></i>
                  </div>
                 
                </div>
              </div>
              <!-- ./col -->
              <div class="col-lg-2 col-6">
                <!-- small box -->
                <div class="small-box">
                  <div class="inner">
                    <h5>Average Order</h5>
                    <p>Rs.45,233.00</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-stats-bars"></i>
                  </div>
                 
                </div>
              </div>
              <!-- ./col -->
              <div class="col-lg-2 col-6">
                <!-- small box -->
                <div class="small-box">
                  <div class="inner">
                    <h5>Revenue</h5>
                    <p>Rs.45,233.00</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-person-add"></i>
                  </div>
                 
                </div>
              </div>
              <div class="col-lg-2 col-6">
                <!-- small box -->
                <div class="small-box">
                  <div class="inner">
                    <h5>Total Vendors</h5>
                     <p>1234</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-person-add"></i>
                  </div>
                 
                </div>
              </div>
              <div class="col-lg-2 col-6">
                <!-- small box -->
                <div class="small-box">
                  <div class="inner">
                    <h5>Total Sales</h5>
                     <p>1234</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-person-add"></i>
                  </div>
                 
                </div>
              </div>
              <!-- ./col -->
              <div class="col-lg-2 col-6">
                <!-- small box -->
                <div class="small-box">
                  <div class="inner">
                    <h5>Total Return</h5>
                     <p>1234</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-pie-graph"></i>
                  </div>
                 
                </div>
              </div>

            </section>

            <!-- top box end -->

            <div class="">
              <div class="clearfix"></div>
  
              <div class="row" style="display: block;">
                <div class="col-md-8 col-sm-4">
                  <div class="x_panel">
                    <div class="x_title">
                   
               
                      <div class="tab">
                        <button class="tablinks" onclick="openCity(event, 'London')">Bestsellers</button>
                        <button class="tablinks" onclick="openCity(event, 'Paris')">MostViewed </button>
                        <button class="tablinks" onclick="openCity(event, 'Tokyo')">NewCustomers</button>
                      </div>


                      <div class="clearfix"></div>
                    </div>
                      <div id="London" class="tabcontent">
                        <div>
                        
                          <table class="table">
                            <thead>
                              <tr>
                              
                                <th>Search Team</th>
                                <th>Price </th>
                                <th>Quantity</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>Lorem ipsum</td>
                                <td>22</td>
                                <td>22</td>
                              </tr>
                              <tr>
                                <td>Lorem ipsum</td>
                                <td>22</td>
                                <td>22</td>
                              </tr>
                              <tr>
                                <td>Lorem ipsum</td>
                                <td>22</td>
                                <td>22</td>
                              </tr>
                              <tr>
                                <td>Lorem ipsum</td>
                                <td>22</td>
                                <td>22</td>
                              </tr>
                              <tr>
                                <td>Lorem ipsum</td>
                                <td>22</td>
                                <td>22</td>
                              </tr>
                              <tr>
                                <td>Lorem ipsum</td>
                                <td>22</td>
                                <td>22</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>

                      <div id="Paris" class="tabcontent">
                        <div>
                        
                          <table class="table">
                            <thead>
                              <tr>
                              
                                <th>Search Team</th>
                                <th>Price </th>
                                <th>Quantity</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>Lorem ipsum</td>
                                <td>22</td>
                                <td>22</td>
                              </tr>
                          
                              
                                <td>Lorem ipsum</td>
                                <td>22</td>
                                <td>22</td>
                              </tr>
                              <tr>
                                <td>Lorem ipsum</td>
                                <td>22</td>
                                <td>22</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>

                      <div id="Tokyo" class="tabcontent">
                        <div>
                        
                          <table class="table">
                            <thead>
                              <tr>
                              
                                <th>Search Team</th>
                                <th>Price </th>
                                <th>Quantity</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>Lorem ipsum</td>
                                <td>22</td>
                                <td>22</td>
                              </tr>
                               <tr>
                                <td>Lorem ipsum</td>
                                <td>22</td>
                                <td>22</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>

                  </div>
                </div>
  
  
                <div class="col-md-4 col-sm-4">
                  <div class="x_panel">
                    <div class="x_title">
                      <h2>Last Search Terms</small></h2>
                      
                      <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
  
                      <table class="table">
                        <thead>
                          <tr>
                          
                            <th>Search Term</th>
                            <th>Item</th>
                            <th>Total</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                        </tbody>
                      </table>
  
                    </div>
                  </div>
                </div>
  
                <div class="clearfix"></div>
  
                <div class="col-md-4 col-sm-4  ">
                  <div class="x_panel">
                    <div class="x_title">
                      <h2>Last Search Terms</small></h2>
                      <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                      <table class="table table-hover">
                        <thead>
                          <tr>
                          
                            <th>Search Term</th>
                            <th>Result</th>
                            <th>Uses</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                        </tbody>
                      </table>
  
                    </div>
                  </div>
                </div>


                <div class="col-md-4 col-sm-4  ">
                  <div class="x_panel">
                    <div class="x_title">
                      <h2>Top Search Option</small></h2>
                      <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                      <table class="table table-hover">
                        <thead>
                          <tr>
                          
                            <th>Search Term</th>
                            <th>Result</th>
                            <th>Uses</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                        </tbody>
                      </table>
  
  
                    </div>
                  </div>
                </div>




                    



  
                <div class="col-md-4 col-sm-6  ">
                  <div class="x_panel">
                    <div class="x_title">
                      <h2>Vender List</small></h2>
                     <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
  
                      <table class="table table-bordered">
                        <thead>
                          <tr>
                          
                            <th>Vender</th>
                            <th>Products</th>
                            <th>Sales</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                          <tr>
                            <td>Lorem ipsum</td>
                            <td>22</td>
                            <td>22</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                 <div class="clearfix"></div>  
              
                 <!-- / page containt -->
        
    <?php include("includes/js.php")?>
    <?php include("includes/footer.php")?>
  </body>
  
</html>