<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IRISH DEER </title>
    <?php include("includes/css.php")?>
  <style>
     
       </style>
  </head>
    
  <body class="nav-md">
    <div class="container body">
    <div class="position-absolute mt-3 ml-5"><h4 class="pl-5"><b>#12312442</b></h4></div>
      <div class="main_container">
           <!-- top navigation -->
           <?php include("includes/side_nav.php")?>
             <!-- end navigation -->
             <div class="right_col" role="main">
             <!-- top buttons -->
            
                    <div class="row">
                            <div class="col-sm">
                                <a href="">Back</a>
                            </div>
                        <div class="col-sm">
                          <div class="float-right">
                            <button type="button" class="btn btn-primary">Send Email</button>
                            <button type="button" class="btn btn-primary">Credit Memo</button>
                            <button type="button" class="btn btn-primary">Print</button>
                          </div>
                        </div>
                    </div>
               
              <!-- end top buttons --> 
              <!-- page content -->
                <div class="box_shedow mt-4 mb-5">
                    <div class="pl-3 pt-4">
                        <h5><b>Order & Account Information</b></h5>
                    </div>
                    <hr/>
                    <div class="container p-3">
                        <div class="row">
                            <div class="col-sm-6">
                                <h5 class="pb-2">Order #24234(The orxder confirmation email is not send)</h5>
                            <table class="table table-striped">
                                  <tbody>
                                    <tr>
                                    <td>Order Date</td>
                                    <td class="text-right">sep 3,2020,7:34:12 PM</td>
                                    </tr>
                                    <tr>
                                    <td>Order Status</td>
                                    <td class="text-right">Procesing    </td>
                                    </tr>
                                    <tr>
                                    <td>Purchased From</td>
                                    <td class="text-right">Website</td>
                                    </tr>
                                    <tr>
                                    <td>Place from IP</td>
                                    <td class="text-right">234.434.325.223</td>
                                    </tr>
                                </tbody>
                                </table>
                            </div>
                            <div class="col-sm-6">
                            <div class="d-flex">
                                    <h5><b>Account Information</b></h5>
                                    <h5 class="pl-3"><a href="" class="text-primary">Edit Customer</a></h5>
                                </div>
                            <table class="table table-striped">
                                  <tbody>
                                    <tr>
                                    <td>Customer Name</td>
                                    <td class="text-right">Ram Kumar</td>
                                    </tr>
                                    <tr>
                                    <td>Email</td>
                                    <td class="text-right">ramk@gmail.com</td>
                                    </tr>
                                    <tr>
                                    <td>Customer Group</td>
                                    <td class="text-right">General</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    

                    <h5 class="p-3">Address information</h5>
                    <hr/>
                    <div class="container p-3">
                        <div class="row">
                            <div class="col">
                                <div class="d-flex">
                                    <h5>Billing Address</h5>
                                    <h5 class="pl-3"><a href="" class="text-primary">Edit</a></h5>
                                </div>
                                <ul class="list-group p-2">
                                <li class="list-group">123 Street</li>
                                <li class="list-group">3rd layout</li>
                                <li class="list-group">Hydrabad</li>
                                <li class="list-group">India</li>
                                <li class="list-group">T:9999111100</li>
                                </ul>
                            </div>
                            <div class="col">
                            <div class="d-flex">
                                    <h5>Billing Address</h5>
                                    <h5 class="pl-3"><a href="" class="text-primary">Edit</a></h5>
                                </div>
                                <ul class="list-group p-2">
                                <li class="list-group">123 Street</li>
                                <li class="list-group">3rd layout</li>
                                <li class="list-group">Hydrabad</li>
                                <li class="list-group">India</li>
                                <li class="list-group">T:9999111100</li>
                                </ul>
                            </div>
                        </div>
                   </div>

                   <h5 class="p-3">Payment & Shipment Method</h5>
                    <hr/>
                    <div class="container p-3">
                        <div class="row">
                            <div class="col">
                                <h5>Payment Information</h5>
                                <ul class="list-group p-2">
                                <li class="list-group">Razorpay</li>
                                <li class="list-group">The order was paced using INR.</li>
                             
                                </ul>
                            </div>
                            <div class="col">
                            <h5>Shipping Information</h5>
                                <ul class="list-group p-2">
                                <li class="list-group">Flat rate-Fixed</li>
                                <li class="list-group">Total Shipping Charges Rs.10.00</li>
                                </ul>
                            </div>
                        </div>
                   </div>

                   <h5 class="p-3">Item Invoiced</h5>
                    
                    <div class="pl-3 pr-3">
                    <div style="overflow-x:auto;">
                      <table class="table table-striped projects mt-3">
                        <thead>    
                        <tr>
                          <th style="width: 18%">Products</th>
                          <th>Price</th>
                          <th>Qty</th>
                          <th>Subtotal</th>
                          <th>Tax Amount</th>
                           <th>Discount Amount</th>
                           <th>Row Total</th>
                           </tr>
                        </thead>
                        <tr>
                            <td>Salwaar Kameez Simple <br/>SKU:23442</td>
                            <td>Rs.3434</td>
                            <td>1</td>
                            <td>Rs.3434</td>
                            <td>0</td>
                            <td>0</td>
                            <td>Rs.3434</td>
                          </tr>
                          <tr>
                            <td>Salwaar Kameez Simple <br/>SKU:23442</td>
                            <td>Rs.3434</td>
                            <td>1</td>
                            <td>Rs.3434</td>
                            <td>0</td>
                            <td>0</td>
                            <td>Rs.3434</td>
                          </tr>
                          <tr>
                            <td>Salwaar Kameez Simple <br/>SKU:23442</td>
                            <td>Rs.3434</td>
                            <td>1</td>
                            <td>Rs.3434</td>
                            <td>0</td>
                            <td>0</td>
                            <td>Rs.3434</td>
                          </tr>                    
                     </table>
                    </div>
                  </div>


                  <h5 class="p-3">Order Total</h5>
                    <hr/>
                    <div class="container p-3">
                        <div class="row">
                            <div class="col-sm-6">
                                <h5 class="pb-2">Invoice History</h5>
                                <div class="form-group">
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Enter Comment Text here" style="border: none; box-shadow: none;
                                    background: #eaeaea;"></textarea>
                                </div>
                                <div class="form-check">
                                  <label class="form-check-label pt-2">
                                    <input type="checkbox" class="form-check-input" value=""><h6>Notify Customer by Email</h6>
                                  </label>
                              </div>
                              <button type="submit" class="btn btn-primary pt-1 pb-1 pl-2 pr-2">Submit Comment</button>
                            </div>
                            <div class="col-sm-6">
                            <h5 class="pb-2">Account Information</h5>
                            <table class="table table-striped">
                                  <tbody>
                                    <tr>
                                    <td>Subtotal</td>
                                    <td class="text-right">Rs.3243</td>
                                    </tr>
                                    <tr>
                                    <td>Shiping & Handling</td>
                                    <td class="text-right">Rs.10.00</td>
                                    </tr>
                                    <tr>
                                 
                                    <td><b>Grand Total</b></td>
                                    <td class="text-right"><b>Rs.3423</b></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>



                </div>
            <!-- /page content -->
        </div>
     </div>
    <div>
    <?php include("includes/js.php")?>
    <?php include("includes/footer.php")?>
</body>
</html>
