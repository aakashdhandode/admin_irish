<div class="modal fade" id="modalLoginForm">  
    <!-- modal fade -->
        <div class="modal-dialog" role="document">
          <div class="modal-content pt-1 pr-3 pl-3 pb-3">
            <div class="modal-header text-left">
              <h4 class="modal-title w-100 font-weight-bold"><i class="fa fa-filter mr-3"></i>Filter</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
           
            <div class="container">
              <div class="row p-3">
                <div class="col-sm">
                    <h5>Purches Date</h5>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">From</label>
                        <div class="col-sm-10">
                           <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">TO</label>
                        <div class="col-sm-10">
                           <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                        </div>
                    </div>
                    <div class="form-group row">                      
                        <div class="col-sm-12 p-2">
                            <h5>Bll-to Name</h5>
                           <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                        </div>
                    </div>



                </div>


                <div class="col-sm">
                   <h5>Purches Date</h5>
                     <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">From</label>
                        <div class="col-sm-10">
                        <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">To</label>
                        <div class="col-sm-10">
                        <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                        </div>
                      </div>
                      <div class="form-group row">                      
                        <div class="col-sm-12 p-2">
                            <h5>Bll-to Name</h5>
                           <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                        </div>
                    </div>
                </div>


                <div class="col-sm">
                  <h5>Status</h5>
                  <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">From</label>
                      <div class="col-sm-10">
                       <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                    </div>
                </div>
                <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label"></label>
                        <div class="col-sm-12">
                        
                        </div>
                      </div>

                  <div class="form-group row">                      
                        <div class="col-sm-12 mt-4">
                            <h5>Bll-to Name</h5>
                           <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                        </div>
                  </div>
                  <button type="button" class="btn  btn-sm float-right save_btn" style="width:48%;     margin-top: -6px;">Apply Filter</button>
                  <button type="button" class="btn  btn-sm float-right text-primary" style="width:48%"><b>Cancel</b></button>

              </div>
            </div>
          </div>
        </div>
      </div>