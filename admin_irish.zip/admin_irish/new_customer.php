<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IRISH DEER </title>
    <?php include("includes/css.php")?>
  <style>
 .form-control{ border: 1px solid #ced4da00; }
  </style>
  </head>

  <body class="nav-md">
    <div class="container body">
    <div class="position-absolute mt-3 ml-5"><h4 class="pl-5"><b>New Customer</b></h4></div>
      <div class="main_container">
      <?php include("includes/side_nav.php")?>
        <!-- /top navigation -->


        <!-- page content -->
        <div class="right_col" role="main">
       
        
                <form>  
                    
                  <button type="button" class="btn  btn-sm float-right save_btn mt-0">Save</button>
                  
                   <div class="container form_center">
                   <div class="mt-5 mb-5 pb-5">  
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Froup</label>
                        <div class="col-sm-10">
                          <select class="form-control w-50">
                              <option>General</option>
                              <option>..</option>
                              <option>..</option>
                            </select>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Name Prefix</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="inputEmail3" placeholder="MR/Mrs/Ms">
                        </div>
                      </div>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">First Name</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="inputEmail3" placeholder="First Name">
                        </div>
                      </div>


                    <div class="form-group row">
                      <label for="inputPassword3" class="col-sm-2 col-form-label">Last Name</label>
                      <div class="col-sm-10">
                        <input type="" class="form-control" id="inputPassword3" placeholder="Last Name">
                      </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Email</label>
                        <div class="col-sm-10">
                          <input type="" class="form-control" id="inputPassword3" placeholder="abc@mail.com">
                        </div>
                      </div>
                        <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Date of Birth</label>
                        <div class="col-sm-10">
                             <input type="date" class="form-control w-50" id="inputPassword3" placeholder="">
                        </div>
                      </div>
                       <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Tax/Vat No</label>
                        <div class="col-sm-10">
                          <input type="" class="form-control" id="inputPassword3" placeholder="#######">
                        </div>
                      </div>
                        <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Gender</label>
                        <div class="col-sm-10">
                          <select class="form-control w-50">
                              <option>Gender</option>
                              <option>Male</option>
                              <option>Female</option>

                            </select>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Phone Number</label>
                        <div class="col-sm-10">
                          <input type="tel" class="form-control" id="phone" placeholder="+91 999 999 9999" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}">
                        </div>
                      </div>
      
                    </div>
                    </div>
                  </form>

            
      </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
           
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>
    <?php include("includes/js.php")?>
    <?php include("includes/footer.php")?>
  </body>
</html>