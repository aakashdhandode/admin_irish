<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php include("includes/css.php")?>
    <style>
      .form_center { width: 100%;}
    </style>
  </head>

  <body class="nav-md">
    <div class="container body">
    <div class="position-absolute mt-3 ml-5"><h4 class="pl-5"><b>Categories</b></h4></div>
      <div class="main_container">
        

        <!-- top navigation -->
        <?php include("includes/side_nav.php")?>
        <!-- /top navigation -->

<!-- page content -->
     <div class="right_col" role="main">
    <div class="row">
            <div class="col-3 mt-5 mtl-5" style="    padding-left: 45px;">
                                
                    <div class="tab pt-5">
                    
                      <button class="tablinks text-primary" onclick="openCity(event, 'London')"><b>Collapse All</b></h5> </button>
                      
                      <button class="tablinks text-primary" onclick="openCity(event, 'Paris')">Expand All</button>
                    </div>

                    <div class="side_tab">
                        <div id="London" class="tabcontent">
                          <p>Default Categories</p>
                          <div class="text-center">
                          <p>SubCategories1</p>
                          <p>SubCategories2</p>
                          <p>SubCategories3</p>
                          <p>SubCategories4</p>
                          </div>
                        </div>

                        <div id="Paris" class="tabcontent">
                        <p>Categories</p>
                          <div class="text-center">
                          <p>SubCategories1</p>
                          <p>SubCategories2</p>
                       
                          </div>
                        </div>
                    </div>

                       




              </div>
                  <div class="col-9 border-left">
                  <div class="col-6 float-right">
                  <button type="button" class="btn btn-primary p-1 pl-2 pr-2"><a href="new_product.php" style="color:white  ">+ Add Product</a></button>
                  <button type="button" class="btn btn-primary  p-1 pl-2 pr-2">+ Add Products in Bulk</button>
                  </div>  
       
   <form>
    <div class="container form_center">        
     <div class="form-group row">
         <label for="inputEmail3" class="col-sm-2 col-form-label">Enable Product</label>
         <div class="col-sm-10">
             <label class="switch">
                 <input type="checkbox" checked>
                 <span class="slider round"></span>
               </label><span>Yes</span>
               
         </div>
     </div>
     <div class="form-group row">
         <label for="inputEmail3" class="col-sm-2 col-form-label">Include in Menu</label>
         <div class="col-sm-10">
             <label class="switch">
                 <input type="checkbox" checked>
                 <span class="slider round"></span>
               </label><span>Yes</span>
               
         </div>
     </div>
     <div class="form-group row">
         <label for="inputEmail3" class="col-sm-2 col-form-label">Category Name</label>
         <div class="col-sm-6">
           <input type="text" class="form-control" id="inputEmail3" placeholder="SubCategory 1">
         </div>
       </div>
       <div class="form-group row">
         <label for="inputEmail3" class="col-sm-2 col-form-label">Category Images</label>
         <div class="col-sm-10 pt-2">
             <input type="file" id="myFile" name="filename">
             <p >max.each file size:2MB. Allowed file type:JPG,GIF,PNG</p>
              <div class="img_box"></div> <h><b>D342.jpg</b></h6><p>1250 * 1875 , 134kb</p>
              
         </div>
       </div>             
       <div class="form-group row">
         <label for="inputEmail3" class="col-sm-2 col-form-label">Description</label>
         <div class="col-sm-6">
             <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
         </div>
       </div>
       
       <div class="form-group row">
         <label for="inputEmail3" class="col-sm-2 col-form-label">Product in Category</label>
         <div class="col-sm-9">
            <hr/>
         </div>
       </div>
       <div class="x_content">                     

         <!-- start project list -->
         <div style="overflow-x:auto;">
         <table class="table table-striped projects">
           <thead>
             <tr>
               <th style="width: 1%">#</th>
               <th style="width: 1%">ID</th>
               <th style="width: 35%">Name</th>
               <th>SKU</th>
               <th>Price</th>
               <th>Quantity</th>
               <th>Visibility</th>
               <th>Status</th>
             </tr>
           </thead>
           <tbody>
             <tr>
               <td>#</td>
               <td>
                 <a>32</a>
               </td>
                <td>
                 <p>Handloom Silk sarees all over thread butti with contrast border and palla.</p>
               </td>
               <td>
                 <p>5S34</p>
            
               </td>
               <td>
                 <p>Rs. 3232</p>
               </td>
               <td>
                 <p>4000</p>
               </td>
               <td>
                 <p>Catelog serch</p>
               </td>
               <td>
                 <p>Enabled</p>
               </td>
             </tr>

             <tr>
                 <td>#</td>
                 <td>
                   <a>32</a>
                 </td>
                  <td>
                   <p>Handloom Silk sarees all over thread butti with contrast border and palla.</p>
                 </td>
                 <td>
                   <p>5S34</p>
              
                 </td>
                 <td>
                   <p>Rs. 3232</p>
                 </td>
                 <td>
                   <p>4000</p>
                 </td>
                 <td>
                   <p>Catelog serch</p>
                 </td>
                 <td>
                   <p>Enabled</p>
                 </td>
               </tr>
               <tr>
                 <td>#</td>
                 <td>
                   <a>32</a>
                 </td>
                  <td>
                   <p>Handloom Silk sarees all over thread butti with contrast border and palla.</p>
                 </td>
                 <td>
                   <p>5S34</p>
              
                 </td>
                 <td>
                   <p>Rs. 3232</p>
                 </td>
                 <td>
                   <p>4000</p>
                 </td>
                 <td>
                   <p>Catelog serch</p>
                 </td>
                 <td>
                   <p>Enabled</p>
                 </td>
               </tr>

               <tr>
                 <td>#</td>
                 <td>
                   <a>32</a>
                 </td>
                  <td>
                   <p>Handloom Silk sarees all over thread butti with contrast border and palla.</p>
                 </td>
                 <td>
                   <p>5S34</p>
              
                 </td>
                 <td>
                   <p>Rs. 3232</p>
                 </td>
                 <td>
                   <p>4000</p>
                 </td>
                 <td>
                   <p>Catelog serch</p>
                 </td>
                 <td>
                   <p>Enabled</p>
                 </td>
               </tr>
               <tr>
                 <td>#</td>
                 <td>
                   <a>32</a>
                 </td>
                  <td>
                   <p>Handloom Silk sarees all over thread butti with contrast border and palla.</p>
                 </td>
                 <td>
                   <p>5S34</p>
              
                 </td>
                 <td>
                   <p>Rs. 3232</p>
                 </td>
                 <td>
                   <p>4000</p>
                 </td>
                 <td>
                   <p>Catelog serch</p>
                 </td>
                 <td>
                   <p>Enabled</p>
                 </td>
               </tr>
           </tbody>
         </table>
      </div>
         <!-- end project list -->
       </div>
       <div class="form-group row">
        <label for="inputEmail3" class="col-sm-3 col-form-label">Search Engine Optimization</label>
        <div class="col-sm-9">
           <hr/>
        </div>
      </div>
      <div>
      <div class="form-group row">
        <label for="inputEmail3" class="col-sm-3 col-form-label text-right">Meta Title</label>
        <div class="col-sm-5">
          <input type="text" class="form-control" id="inputEmail3" placeholder="Enter here">
        </div>
      </div>
      <div class="form-group row">
        <label for="inputEmail3" class="col-sm-3 col-form-label text-right">Meta Keyword</label>
        <div class="col-sm-5">
          <input type="text" class="form-control" id="inputEmail3" placeholder="Enter here">
        </div>
      </div>
      <div class="form-group row">
        <label for="inputEmail3" class="col-sm-3 col-form-label text-right">Meta Description</label>
        <div class="col-sm-5">
          <input type="text" class="form-control" id="inputEmail3" placeholder="enter here">
        </div>
      </div>
      </div>

    </div>
   </form>   
 </div>
</div>


<!-- /page content -->

  <?php include("includes/footer.php")?>
  <!-- /footer content -->
</div>
</div>
</div>
<?php include("includes/js.php")?>
<?php include("includes/footer.php")?>
  </body>
</html>