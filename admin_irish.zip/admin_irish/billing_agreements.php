<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IRISH DEER </title>
    <?php include("includes/css.php")?>
    <style>
  
    </style>
  </head>
    
  <body class="nav-md">
    <div class="container body">
    <div class="position-absolute mt-3 ml-5"><h4 class="pl-5"><b>Billing Agreements</b></h4></div>
      <div class="main_container">
           <!-- top navigation -->
           <?php include("includes/side_nav.php")?>
               <!-- /top navigation -->


              <!-- page content -->
        <div class="right_col" role="main">
          <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">                
                  <div class="x_content">                     
                    <!-- top serch boxes -->
                 
                    <div class="row">
                        <div class="col-sm-8">
                         <form>
                            <div class="form-row">
                                <div class="col-5">
                                <input type="text" class="form-control" placeholder="search by keyword">
                                </div><i class="fa fa-search mr-3"></i>
                                <div class="col">
                                <button type="button" class="form-control" placeholder="Filter" ><a href="" class="" data-toggle="modal" data-target="#modalLoginForm"><i class="fa fa-filter mr-3"></i>Filter</a></button>                                </div>
                                <div class="col">
                                  <select id="inputState" class="form-control">
                                    <option selected>Columns</option>
                                    <option>...</option>
                                </select>
                                </div>
                                <div class="col">
                                      <select id="inputState" class="form-control">
                                      <option>Export</option>
                                        <option>...</option>
                                    </select>
                                </div>
                            </div>
                           </form>
                      </div>
                        <div class="col-sm-4 float-right">
                        <button type="button" class="btn btn-primary float-right new_order">+ Create New Order</button>
                        </div>
                       
                        <div class="col-sm-8">
                         <form>
                            <div class="form-row">
                               
                                
                                <div class="col-3">
                                  <select id="inputState" class="form-control">
                                    <option selected>Action</option>
                                    <option>...</option>
                                </select>
                                </div>
                                <div class="col">
                                     <h4 class="p-2">32 record found</h4>
                                </div>
                            </div>
                           </form>
                      </div>
                      <div class="col-sm-4">
                         <div class="pagination float-right">
                        <a href="#">&laquo;</a>
                        <a href="#">1</a>
                        <a class="" href="#">2</a>
                        <a href="#">3</a>
                       
                        <a href="#">&raquo;</a>
                        </div>
                        </div>

                  </div>


                  
                     <!-- / top search box -->

                    <!-- start project list -->
                    <div style="overflow-x:auto;">
                    <table class="table table-striped projects mt-3">
                        <thead>    
                        <tr>
                          <th style="width: 1%">#</th>
                          <th>ID</th>
                          <th>Email</th>
                          <th>First Name</th>
                          <th>Last Name</th>
                          <th>Refrence ID</th>
                           <th>Status</th>
                           <th>Created</th>
                           <th>Uploaded</th>
                        </tr>
                        </thead>

                        

                     </table>
                 </div>
                              <p class="p-3 text-center">No Record Found</p>
                    <!-- end project list -->
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        </div>
        <div class="clearfix"></div>  
        <!-- /page content -->
  <!-- popup filter form -->
  <?php include("filter_popup.php")?>

<!-- / end popUp filter form -->

     </div>
    <div>
<?php include("includes/footer.php")?>

    <?php include("includes/js.php")?>
    
</body>
</html>
