<div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
           
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">

                <ul class="nav side-menu">
                    <li><a href="index.php"><i class="fa fa-tachometer"></i> DASHBORD<span class="fa fa-chevron-down"></span></a>
                 </li>
              
                  <li><a><i class="fa fa-table"></i>PRODUCT <span class="fa fa-chevron-down"></span></a>
                   </li>
                  <li><a><i class="fa fa-fax"></i>SALES <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <li><a href="orders.php">Orders</a></li>
                    <li><a href="invoices.php">Invoices</a></li>
                    <li><a href="shipments.php">Shipments</a></li>
                    <li><a href="credit_memos.php">Credit Memos</a></li>
                    <li><a href="billing_agreements.php">Billing Agreements</a></li>
                    <li><a href="transactions.php">Transaction</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-bar-chart-o"></i>CATALOG<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="product.php">Product</a></li>
                      <li><a href="categories.php">Categories</a></li>
                      
                    </ul>
                  </li>
                  <li><a href="customer.php"><i class="fa fa-user"></i> CUSTOMER<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    
                    </ul>
                  </li>
                  <li><a href="content.php"><i class="fa fa-newspaper-o"></i>CONTANT<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    
                    </ul>
                  </li>
                  <li><a href="users.php"><i class="fa fa-gear"></i>SETTING <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    
                    </ul>
                  </li>
                </ul>
              </div>
              <div class="menu_section">     
              </div>

            </div>
            <!-- /sidebar menu -->

          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
        
            <div class="nav_menu">
                <!-- <div class="nav toggle">
                  <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                </div> -->
                <nav class="nav navbar-nav">
                <ul class=" navbar-right">
                  <li class="nav-item dropdown open" style="padding-left: 15px;">
                    <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                      <img src="images/img.jpg" alt="">Hi, Admin
                    </a>
                    <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item"  href="javascript:;"> Profile</a>
                        <a class="dropdown-item"  href="javascript:;">
                          <span class="badge bg-red pull-right">50%</span>
                          <span>Settings</span>
                        </a>
                    <a class="dropdown-item"  href="javascript:;">Help</a>
                      <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                    </div>
                  </li>
  
                  <li role="presentation" class="nav-item dropdown open">
                    <a href="javascript:;" class="" id="navbarDropdown1" data-toggle="dropdown" aria-expanded="false">
                      <i class="fa fa-bell-o" id="notificaiton"></i>
                      
                    </a>
                    <!-- <ul class="dropdown-menu list-unstyled msg_list" role="menu" aria-labelledby="navbarDropdown1">
                    
                      <li class="nav-item">
                        <div class="text-center">
                          <a class="dropdown-item">
                            <strong>See All Alerts</strong>
                            <i class="fa fa-angle-right"></i>
                          </a>
                        </div>
                      </li>
                    </ul> -->
                  </li>
                    
                  <!-- <li role="presentation" class="nav-item dropdown open">
                    <a href="javascript:;" class="" id="navbarDropdown1" data-toggle="dropdown" aria-expanded="false">
                      <i class="fa fa-search new" id="notificaiton"></i>
                      
                    </a>
                  </li> -->
                  <li role="presentation" class="nav-item dropdown open">
                        <div class="col-lg-6  float-right" style="margin-top: 7px;">
                        <form class="form-horizontal my-2 my-md-0 search-form" [formGroup]="searchForm" role="form" (keyup.enter)="onSubmit()">
                            <div class="input-group">
                              <input type="text" class="form-control" formControlName="searchText" size="50">
                              <span class="input-group-btn fa fa-search form-control-feedback">
                              </span>
                          </div>
                        </form>
                      </div>
                      </li>
                 </ul>
              </nav>
            </div>
          </div>

      
        <!-- /top navigation -->