<footer>
          <div class="text-center">
           <p>Copyright @ ODMS PVT LTD 2020</p>
      </div>
      </footer>