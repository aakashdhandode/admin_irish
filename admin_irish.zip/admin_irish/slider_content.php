<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IRISH DEER </title>
    <?php include("includes/css.php")?>
    <style>

/* Style the tab */
.tab {float: left; width: 20%; height: 300px;

}

.tab button {
    padding: 12px 2px 0 0px;
    width: 100%;
}
.tab button.active {
    border-bottom: none;
    background:#d4dada63;
}

/* Style the tab content */

</style>
</style>
  </head>
    
  <body class="nav-md">
    <div class="container body">
      <div class="position-absolute mt-3 ml-5"><h4 class="pl-5"><b>Invoices</b></h4></div>
      <div class="main_container">
           <!-- top navigation -->
           <?php include("includes/side_nav.php")?>
        <!-- /top navigation -->
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
              <div class="col-sm-4 pb-2 float-right">
                        <button type="button" class="btn btn-primary float-right new_order">Save</button>
                        </div>
                   <div class="x_panel pt-5">
                     <!-- start project list -->
                     <div class="tab">
                        <h6 class="text-center">Home page</h6>
                    <button class="" onclick="openCity(event, '1')" id="defaultOpen">slider</button>
                    <button class="" onclick="openCity(event, '2')">section 1</button>
                    <button class="" onclick="openCity(event, '3')">section 3</button>
                    <button class="" onclick="openCity(event, '4')">section 4</button>
                    <button class="" onclick="openCity(event, '5')">section 5</button>
                    <button class="" onclick="openCity(event, '6')">section 6</button>
                    <button class="" onclick="openCity(event, '7')">section 7</button>


                    
                    </div>

                        <div id="1" class="tabcontent">
                                    <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Slider Images1</label>
                                    <div class="col-sm-10">
                                        <input type="file" id="myFile" name="filename">
                                        <p>max.each file size:2MB. Allowed file type:JPG,GIF,PNG</p>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Slider Images2</label>
                                    <div class="col-sm-10">
                                        <input type="file" id="myFile" name="filename">
                                        <p>max.each file size:2MB. Allowed file type:JPG,GIF,PNG</p>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">slider Images3</label>
                                    <div class="col-sm-10">
                                        <input type="file" id="myFile" name="filename">
                                        <p>max.each file size:2MB. Allowed file type:JPG,GIF,PNG</p>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">
                                           
                                            <button type="button" class="btn btn-secondary">+Add slider</button>
                                    </label>   
                                </div>
                        </div>

                        <div id="2" class="tabcontent">
                                    <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Section Name</label>
                                    <div class="col-sm-6">
                                    <input type="text" class="form-control" id="inputEmail3" placeholder="MR/Mrs/Ms">
                                    </div>
                                </div>
                              <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Block 1</label>
                                    <div class="col-sm-5">
                                    <p><b></b></p>
                                        <input type="file" id="myFile" name="filename">
                                        <p>max.each file size:2MB. Allowed file type:JPG,GIF,PNG</p>
                                    </div>
                                    <div class="col-sm-4">
                                        <p><b> Name</b></p>
                                        <input type="" class="form-control" id="inputPassword3" placeholder="Pants">
                                   
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Block 2</label>
                                    <div class="col-sm-5">
                                    <p><b></b></p>
                                        <input type="file" id="myFile" name="filename">
                                        <p>max.each file size:2MB. Allowed file type:JPG,GIF,PNG</p>
                                    </div>
                                    <div class="col-sm-4">
                                        <p><b> Name</b></p>
                                        <input type="" class="form-control" id="inputPassword3" placeholder="Pants">
                                   
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Block 3</label>
                                    <div class="col-sm-5">
                                    <p><b></b></p>
                                        <input type="file" id="myFile" name="filename">
                                        <p>max.each file size:2MB. Allowed file type:JPG,GIF,PNG</p>
                                    </div>
                                    <div class="col-sm-4">
                                        <p><b> Name</b></p>
                                        <input type="" class="form-control" id="inputPassword3" placeholder="Pants">
                                   
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Block 4</label>
                                    <div class="col-sm-5">
                                    <p><b></b></p>
                                        <input type="file" id="myFile" name="filename">
                                        <p>max.each file size:2MB. Allowed file type:JPG,GIF,PNG</p>
                                    </div>
                                    <div class="col-sm-4">
                                        <p><b> Name</b></p>
                                        <input type="" class="form-control" id="inputPassword3" placeholder="Pants">
                                   
                                    </div>
                                </div>
                                
                        </div>

                        <div id="3" class="tabcontent">
                        <h3>Tokyo</h3>
                        <p>Tokyo is the capital of Japan.</p>
                        </div>
                        <div id="4" class="tabcontent">
                        <h3>Tokyo</h3>
                        <p>Tokyo is the capital of Japan.</p>
                        </div>
                        <div id="5" class="tabcontent">
                        <h3>Tokyo</h3>
                        <p>Tokyo is the capital of Japan.</p>
                        </div>
                        <div id="6" class="tabcontent">
                        <h3>Tokyo</h3>
                        <p>Tokyo is the capital of Japan.</p>
                        </div>
                        <div id="7" class="tabcontent">
                        <h3>Tokyo</h3>
                        <p>Tokyo is the capital of Japan.</p>
                        </div>

<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>



                    <!-- end project list -->        
                </div>
              </div>
            </div>
          </div>
       
        <!-- /page content -->

     </div>
    <div>
    <?php include("includes/js.php")?>
    <?php include("includes/footer.php")?>
    <script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
</body>
</html>
