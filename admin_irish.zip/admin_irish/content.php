<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IRISH DEER </title>
    <?php include("includes/css.php")?>
    <style>
  
    </style>
  </head>
    
  <body class="nav-md">
    <div class="container body">
      <div class="position-absolute mt-3 ml-5"><h4 class="pl-5"><b>Invoices</b></h4></div>
      <div class="main_container">
           <!-- top navigation -->
           <?php include("includes/side_nav.php")?>
        <!-- /top navigation -->
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                    <form>
                        <div class="form-row">
                         <div class="col-3">
                         <input type="text" class="form-control" placeholder="search by keyword">
                         </div><i class="fa fa-search mr-3"></i>                                       
                      </div>
                    </form> 
                    <div class="col">
                        <h4 class="p-2">Home Page Section</h4>
                    </div>
                <div class="x_panel">
                  <div class="x_content">    
                         <!-- start project list -->
                    <div style="overflow-x:auto;">
                    <table class="table table-striped projects mt-3">
                        <thead>    
                           <tr>
                          <th>Section</th>
                          <th>Section Name</th>
                          <th>Action</th>
                           </tr>
                            </thead>
                            <tr>
                            <th>slider</th>
                            <td>---</td>
                            <td><a href="slider_content.php">Edit</a></td> 
                            </tr>

                            <tr>
                            <th>Section 1</th>
                            <td>style for her</td>
                            <td><a href="section_content.php">Edit</a></td>
                            </tr>

                            <tr>
                            <th>Section 2</th>
                            <td>style for him</td>
                            <td><a href="section_content.php">Edit</a></td>
                            </tr>

                            <tr>
                            <th>Section 3</th>
                            <td>Ethnic wear</td>
                            <td><a href="section_content.php">Edit</a></td>
                            </tr>

                            <tr>
                            <th>Section 4</th>
                            <td>Offers for you</td>
                            <td><a href="section_content.php">Edit</a></td>
                            </tr>

                            <tr>
                            <th>Section 5</th>
                            <td>Top picks</td>
                            <td><a href="section_content.php">Edit</a></td>
                            </tr>
                            <tr>
                             <tr>
                            <th>Section 6</th>
                            <td>---</td>
                            <td><a href="section_content.php">Edit</a></td>
                            </tr>
                            <tr>
                            <th>Section 7</th>
                            <td>---</td>
                            <td><a href="section_content.php">Edit</a></td>
                            </tr>

                        </table>
                </div>
                    <!-- end project list -->
                        
                  </div>
                </div>
              </div>
            </div>
          </div>
       
        <!-- /page content -->

     </div>
    <div>
    
    <?php include("includes/footer.php")?>
    <?php include("includes/js.php")?>
    
    
</body>
</html>
