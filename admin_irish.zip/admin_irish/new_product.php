<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IRISH DEER </title>
    <?php include("includes/css.php")?>
  <style>
 .form-control{ border: 1px solid #ced4da00; }
  </style>
  </head>

  <body class="nav-md">
    <div class="container body">
    <div class="position-absolute mt-3 ml-5"><h4 class="pl-5"><b>New Product</b></h4></div>
      <div class="main_container">
      <?php include("includes/side_nav.php")?>
        <!-- /top navigation -->


        <!-- page content -->
        <div class="right_col" role="main">
       
        
                <form>  
                  
            <button type="button" class="btn  btn-sm float-right save_product">Save</button>
                   <div class="container form_center">  

                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Enable Product</label>
                        <div class="col-sm-10">
                            <label class="switch">
                                <input type="checkbox" checked>
                                <span class="slider round"></span>
                              </label><span class="pl-2" style="font-size:15px;margin-top:2px"><b>Yes</b></span>
                              
                        </div>
                    </div>
                    
                    <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">Attribute set</label>
                      <div class="col-sm-10">
                        <select class="form-control">
                            <option>Default</option>
                          </select>
                      </div>
                    </div>

                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Product Name</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="inputEmail3" placeholder="name">
                        </div>
                      </div>


                    <div class="form-group row">
                      <label for="inputPassword3" class="col-sm-2 col-form-label">SKU</label>
                      <div class="col-sm-10">
                        <input type="" class="form-control" id="inputPassword3" placeholder="SKU">
                      </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Price</label>
                        <div class="col-sm-10">
                          <input type="" class="form-control" id="inputPassword3" placeholder="Price">
                        </div>
                      </div>

                      
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Tax Class</label>
                        <div class="col-sm-10">
                          <select class="form-control w-50">
                              <option>Taxable</option>
                            </select>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Quantity</label>
                        <div class="col-sm-10">
                          <select class="form-control w-50">
                              <option>Qty</option>
                            </select>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Stock Status</label>
                        <div class="col-sm-10">
                          <input type="" class="form-control" id="inputPassword3" placeholder="In Stock">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Weight</label>
                        <div class="col-sm-10">
                            <div class="form-row">
                                <div class="form-group col-md-6">
                              
                                  <input type="text" class="form-control" id="inputCity" placeholder="Ibs">
                                </div>
                                <div class="form-group col-md-6">
                               
                                  <select id="inputState" class="form-control">
                                    <option selected>This item has weight</option>
                                    <option>...</option>
                                  </select>
                                </div>       
                         </div>
                      </div>
                    </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Visibility</label>
                        <div class="col-sm-10">
                          <select class="form-control w-50">
                              <option>Catalog,search</option>
                            </select>
                        </div>
                      </div>
                      <button type="button" class="btn  btn-sm float-right save_btn new_btn" >New Categories</button>
                
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Categories</label>
                        <div class="col-sm-10">
                          <select class="form-control">
                              <option>select</option>
                            </select>
                        </div>
                      </div>
                      
                      <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Set Product as New From</label>
                        <div class="col-sm-10">
                            <div class="form-row">
                                <div class="form-group col-md-6">
                              
                                  <input type="text" class="form-control" id="inputCity">
                                </div>
                                <div class="form-group col-md-6">
                               
                                  <select id="inputState" class="form-control">
                                    <option selected>Choose...</option>
                                    <option>...</option>
                                  </select>
                                </div>       
                         </div>
                      </div>
                    </div>

                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Color</label>
                        <div class="col-sm-10">
                          <select class="form-control w-50">
                              <option>Select</option>
                            </select>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Primary Images</label>
                        <div class="col-sm-10">
                            <input type="file" id="myFile" name="filename">
                            <p>max.each file size:2MB. Allowed file type:JPG,GIF,PNG</p>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Secondary Images</label>
                        <div class="col-sm-10">
                            <input type="file" id="myFile" name="filename">
                            <p>max.each file size:2MB. Allowed file type:JPG,GIF,PNG</p>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Attribute</label>
                        <div class="col-sm-10">
                          <hr/>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Menu</label>
                        <div class="col-sm-10">
                          <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Size</label>
                        <div class="col-sm-10">
                          <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Color</label>
                        <div class="col-sm-10">
                          <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Search Engine Optimization</label>
                        <div class="col-sm-10">
                          <hr/>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">URL Key</label>
                        <div class="col-sm-10">
                          <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Meta Title</label>
                        <div class="col-sm-10">
                          <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Meta KeyWords</label>
                        <div class="col-sm-10">
                          <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Meta Description</label>
                        <div class="col-sm-10">
                          <input type="" class="form-control" id="inputEmail3" placeholder="Enter here">
                        </div>
                      </div>

                    </div>
                  </form>

            
      </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
           
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>
    <?php include("includes/js.php")?>
    <?php include("includes/footer.php")?>
  </body>
</html>