<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IRISH DEER </title>
    <?php include("includes/css.php")?>
  </head>

  <body class="nav-md">
    <div class="container body">
    <div class="position-absolute mt-3 ml-5"><h4 class="pl-5"><b>Product</b></h4></div>
      <div class="main_container">
                <!-- top navigation -->
                <?php include("includes/side_nav.php")?>
               <!-- /top navigation -->


        <!-- page content -->
        <div class="right_col" role="main">
          <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">                
                  <div class="x_content">                     
                    <!-- top serch boxes -->
                    <div class="row">
                        <div class="col-sm-5">
                         <form>
                            <div class="form-row">
                                <div class="col-6">
                                <input type="text" class="form-control" placeholder="search by keyword">
                                </div><i class="fa fa-search mr-3"></i>
                                <div class="col-3">
                                <button type="button" class="form-control" placeholder="Filter" ><a href="" class="" data-toggle="modal" data-target="#modalLoginForm"><i class="fa fa-filter mr-3"></i>Filter</a></button>
                                </div>
                             </div>
                           </form>
                      </div>
                      <div class="col-3"></div>
                        <div class="col-sm-4" style="">
                         <button type="button" class="btn btn-primary  p-1 pl-3 pr-3 ml-5"><a href="new_product.php" style="color:white  ">+ Add Product</a></button>
                        <button type="button" class="btn btn-primary p-1 pl-3 pr-3 ml-3"  data-toggle="modal" data-target="#exampleModalCenter">
                        + Add Products in Bulk
                        </button>
                        
                        </div>
                       
                        <div class="col-sm-8">
                         <form>
                            <div class="form-row">
                               
                                
                                <div class="col-3">
                                  <select id="inputState" class="form-control">
                                    <option selected>Action</option>
                                    <option>...</option>
                                </select>
                                </div>
                                <div class="col">
                                     <h4 class="p-2">32 record found</h4>
                                </div>
                            </div>
                           </form>
                      </div>
                      <div class="col-sm-4">
                         <div class="pagination float-right">
                        <a href="#">&laquo;</a>
                        <a href="#">1</a>
                        <a class="" href="#">2</a>
                        <a href="#">3</a>
                       
                        <a href="#">&raquo;</a>
                        </div>
                        </div>

                 </div>

                  
                 <div style="overflow-x:auto;">                 

                    <!-- start project list -->
                    <table class="table table-striped projects">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>id</th>
                          <th>Thumbnail Name</th>
                          <th>Category</th>
                          <th>SKU</th>
                          <th>Price</th>
                          <th>Quantity</th>
                          <th>Scalable Quantity</th>
                          <th>Visibility</th>
                          <th>Status</th>
                           <th>Color</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>#</td>
                          <td>
                            <a>32</a>
                          </td>
                          <td>
                            <ul class="list-inline">
                              <li>
                                <img src="images/user.png" class="avatar" alt="Avatar">
                              </li>
                            </ul>
                          </td>
                          <td>
                            <p>Salwar</p>
                          </td>
                          <td>
                            <p>5S34</p>
                            <!-- <button type="button" class="btn btn-success btn-xs">Success</button> -->
                          </td>
                          <td>
                            <p>Rs. 3232</p>
                          </td>
                          <td>
                            <p>4000</p>
                          </td>
                          <td>
                            <p>5000</p>
                          </td>
                          <td>
                            <p>Catelog serch</p>
                          </td>
                          <td>
                            <p>Enabled</p>
                          </td>
                          <td>
                            <p>Gray</p>
                          </td>
                          <td>
                            <a href="">Edit</a>
                          </td>
                        </tr>

                        <tr>
                            <td>#</td>
                            <td>
                              <a>32</a>
                            </td>
                            <td>
                              <ul class="list-inline">
                                <li>
                                  <img src="images/user.png" class="avatar" alt="Avatar">
                                </li>
                              </ul>
                            </td>
                            <td>
                              <p>Salwar</p>
                            </td>
                            <td>
                              <p>5S34</p>
                              <!-- <button type="button" class="btn btn-success btn-xs">Success</button> -->
                            </td>
                            <td>
                              <p>Rs. 3232</p>
                            </td>
                            <td>
                              <p>4000</p>
                            </td>
                            <td>
                              <p>5000</p>
                            </td>
                            <td>
                              <p>Catelog serch</p>
                            </td>
                            <td>
                              <p>Enabled</p>
                            </td>
                            <td>
                              <p>Gray</p>
                            </td>
                            <td>
                              <a href="">Edit</a>
                            </td>
                          </tr>

                          <tr>
                            <td>#</td>
                            <td>
                              <a>32</a>
                            </td>
                            <td>
                              <ul class="list-inline">
                                <li>
                                  <img src="images/user.png" class="avatar" alt="Avatar">
                                </li>
                              </ul>
                            </td>
                            <td>
                              <p>Salwar</p>
                            </td>
                            <td>
                              <p>5S34</p>
                              <!-- <button type="button" class="btn btn-success btn-xs">Success</button> -->
                            </td>
                            <td>
                              <p>Rs. 3232</p>
                            </td>
                            <td>
                              <p>4000</p>
                            </td>
                            <td>
                              <p>5000</p>
                            </td>
                            <td>
                              <p>Catelog serch</p>
                            </td>
                            <td>
                              <p>Enabled</p>
                            </td>
                            <td>
                              <p>Gray</p>
                            </td>
                            <td>
                              <a href="">Edit</a>
                            </td>
                          </tr>

                          <tr>
                            <td>#</td>
                            <td>
                              <a>32</a>
                            </td>
                            <td>
                              <ul class="list-inline">
                                <li>
                                  <img src="images/user.png" class="avatar" alt="Avatar">
                                </li>
                              </ul>
                            </td>
                            <td>
                              <p>Salwar</p>
                            </td>
                            <td>
                              <p>5S34</p>
                              <!-- <button type="button" class="btn btn-success btn-xs">Success</button> -->
                            </td>
                            <td>
                              <p>Rs. 3232</p>
                            </td>
                            <td>
                              <p>4000</p>
                            </td>
                            <td>
                              <p>5000</p>
                            </td>
                            <td>
                              <p>Catelog serch</p>
                            </td>
                            <td>
                              <p>Enabled</p>
                            </td>
                            <td>
                              <p>Gray</p>
                            </td>
                            <td>
                              <a href="">Edit</a>
                            </td>
                          </tr>

                          <tr>
                            <td>#</td>
                            <td>
                              <a>32</a>
                            </td>
                            <td>
                              <ul class="list-inline">
                                <li>
                                  <img src="images/user.png" class="avatar" alt="Avatar">
                                </li>
                              </ul>
                            </td>
                            <td>
                              <p>Salwar</p>
                            </td>
                            <td>
                              <p>5S34</p>
                              <!-- <button type="button" class="btn btn-success btn-xs">Success</button> -->
                            </td>
                            <td>
                              <p>Rs. 3232</p>
                            </td>
                            <td>
                              <p>4000</p>
                            </td>
                            <td>
                              <p>5000</p>
                            </td>
                            <td>
                              <p>Catelog serch</p>
                            </td>
                            <td>
                              <p>Enabled</p>
                            </td>
                            <td>
                              <p>Gray</p>
                            </td>
                            <td>
                              <a href="">Edit</a>
                            </td>
                          </tr>                    
                      </tbody>
                    </table>
                    <!-- end project list -->

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->
<!-- 
          <div class="modal fade" id="bulk">  
        <div class="modal-dialog" style="max-width: 600px;" role="document">
          <div class="modal-content pt-1 pr-3 pl-3 pb-3">
            <div class="modal-header text-left">
              <h4 class="modal-title w-100 font-weight-bold">Import Bulk Products</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
           
            <div class="container">
              <div class="row p-3">
             
                  <div>
                    <b><a href="test_file.zip"  class="text-primary"  download>Download.CSV template</a></b>
                    <span class="pl-3">and fill details and Upload here. </span>  
                  </div>  
                  <div class="container p-3 my-3 bg-muted">
                  <b><a href="test_file.zip" class="text-primary" download>Upload.CSV for Products</a></b>
                  <div> 
                  <div class="float-right" > 
                  
                  <button type="button" class="btn   btn-sm  text-primary" style=""><b>Cancel</b></button>
                  <button type="button" class="btn  btn-sm btn btn-primary text-white " style=""><b>OK</b></button>
                  </div>
              </div>
          </div>
        </div>
      </div> -->
<!-- Modal -->


<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Import Bulk Products</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <div class="container">
              <div class="row p-3">
             
                  <div>
                    <b><a href="test_file.zip"  class="text-primary"  download>Download.CSV template</a></b>
                    <span class="pl-3">and fill details and Upload here. </span>  
                  </div>  
                  <div class="container p-3 my-3 bg-muted" style="background: #8080801c;">
                  <b><a href="test_file.zip" class="text-primary" download>Upload.CSV for Products</a></b>
                  <div> 
                 </div>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary">OK</button>
      </div>
    </div>
  </div>
</div>


<!-- / end popUp filter form -->
        <?php include("filter_popup.php")?>
      </div>
    </div>
    <?php include("includes/js.php")?>
    <?php include("includes/footer.php")?>
  </body>
</html>