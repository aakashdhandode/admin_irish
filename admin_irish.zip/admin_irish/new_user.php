<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IRISH DEER </title>
    <?php include("includes/css.php")?>
  <style>
 .form-control{ border: 1px solid #ced4da00; }
  </style>
  </head>

  <body class="nav-md">
    <div class="container body">
    <div class="position-absolute mt-3 ml-5"><h4 class="pl-5"><b>New User</b></h4></div>
      <div class="main_container">
      <?php include("includes/side_nav.php")?>
        <!-- /top navigation -->


        <!-- page content -->
        <div class="right_col" role="main">
       
        
                <form>  
                  
            <button type="button" class="btn  btn-sm float-right save_product">Save</button>
                   <div class="container form_center pt-5 pb-5">  

                     <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">User Name</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="inputEmail3" placeholder="User Name">
                        </div>
                      </div>

                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">First Name</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="inputEmail3" placeholder="First Name">
                        </div>
                      </div>


                    <div class="form-group row">
                      <label for="inputPassword3" class="col-sm-2 col-form-label">Last Name</label>
                      <div class="col-sm-10">
                        <input type="" class="form-control" id="inputPassword3" placeholder="Last Name">
                      </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Email</label>
                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputPassword3" placeholder="Email">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Password</label>
                        <div class="col-sm-10">
                          <input type="password" class="form-control" id="inputPassword3" placeholder="************">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Password confirmation</label>
                        <div class="col-sm-10">
                          <input type="password" class="form-control" id="inputPassword3" placeholder="*************">
                        </div>
                      </div>

                      
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Location</label>
                        <div class="col-sm-10">
                          <select class="form-control w-50">
                              <option>India(English)</option>
                            </select>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">This account is</label>
                        <div class="col-sm-10">
                          <select class="form-control w-50">
                              <option>Active</option>
                              <option>...</option>
                            </select>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">User Role</label>
                        <div class="col-sm-10">
                          <select class="form-control w-50">
                              <option>Assign Role</option>
                              <option>...</option>
                            </select>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Phone Number</label>
                        <div class="col-sm-10">
                          <input type="" class="form-control" id="inputPassword3" placeholder="+91 999 999 9999">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label">Your Password</label>
                        <div class="col-sm-10">
                          <input type="" class="form-control" id="inputPassword3" placeholder="Your password">
                        </div>
                      </div>


                    </div>
                  </form>
      </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
           
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>
    <?php include("includes/js.php")?>
    <?php include("includes/footer.php")?>
  </body>
</html>